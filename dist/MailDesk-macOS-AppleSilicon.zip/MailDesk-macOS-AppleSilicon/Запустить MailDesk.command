#!/bin/sh
cd "$(dirname "$0")"
exec ./MailDesk.app/Contents/MacOS/MailDesk
